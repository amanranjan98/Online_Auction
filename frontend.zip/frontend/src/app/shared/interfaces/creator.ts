export interface Creator {
  _id: string;
  email: string;
}
